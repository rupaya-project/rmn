Rupaya MasterNode (rmn) is a cli tool to help you run a Rupaya masternode

## Running and applying a masternode

If you are consulting this repo, it's probably because you want to run a masternode.
For complete guidelines on running a masternode candidate, please refer to the [documentation](https://docs.rupx.io/masternode/requirements/).
